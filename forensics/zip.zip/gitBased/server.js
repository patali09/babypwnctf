const { Client } = require('ssh2');

const connSettings = {
  host: '',
  port: 22, // Default SSH port
  username: 'techparva3',
  privateKey: ```Creds removed````
};

const client = new Client();

client.on('ready', () => {
  console.log('SSH connection successful');
  
  client.sftp((err, sftp) => {
    if (err) throw err;

    sftp.readFile('flag.txt', 'utf-8', (err, data) => {
      if (err) throw err;
      console.log('Content of flag.txt:', data);
      client.end();
    });
  });
});

client.on('error', (err) => {
  console.error('Error:', err);
  client.end();
});

client.connect(connSettings);

